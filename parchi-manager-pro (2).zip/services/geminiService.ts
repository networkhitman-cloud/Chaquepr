
import { GoogleGenAI } from "@google/genai";
import { Entry } from "../types";

export const getFinancialInsights = async (entries: Entry[]): Promise<string> => {
  if (entries.length === 0) return "No data available to analyze yet.";

  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const model = "gemini-3-flash-preview";

  const dataSummary = entries.map(e => ({
    party: e.partyName,
    category: e.category,
    amount: e.totalAmount,
    status: e.status,
    date: e.date
  }));

  const prompt = `
    As a senior financial advisor, analyze the following transaction records for "Parchi Manager Pro" users.
    Provide a concise, professional executive summary (max 200 words).
    Identify:
    1. The biggest debtors/creditors.
    2. Any alarming trends (e.g., high overdue amounts).
    3. Suggestions for better cash flow.

    Data: ${JSON.stringify(dataSummary)}
  `;

  try {
    const response = await ai.models.generateContent({
      model,
      contents: prompt,
      config: {
        thinkingConfig: { thinkingBudget: 0 }
      }
    });
    return response.text || "Could not generate insights at this time.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Error connecting to AI advisor. Please try again later.";
  }
};
