
import React from 'react';
import { Entry } from '../types';

interface HistoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  entry: Entry;
}

const HistoryModal: React.FC<HistoryModalProps> = ({ isOpen, onClose, entry }) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
      <div className="bg-white rounded-3xl shadow-2xl w-full max-w-lg overflow-hidden flex flex-col max-h-[80vh] animate-in zoom-in-95 duration-300">
        <div className="px-8 py-6 border-b border-slate-100 flex items-center justify-between">
          <div>
            <h2 className="text-xl font-bold text-slate-800">Transaction History</h2>
            <p className="text-xs text-slate-400 mt-1">{entry.partyName} Ledger</p>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600 transition-colors">✕</button>
        </div>

        <div className="flex-1 p-8 overflow-y-auto">
          <div className="space-y-6">
            <div className="flex items-start gap-4">
              <div className="mt-1 w-8 h-8 rounded-full bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold text-xs">0</div>
              <div className="flex-1 border-b border-slate-100 pb-4">
                <div className="flex justify-between items-start mb-1">
                  <p className="text-sm font-bold text-slate-800">Opening Balance / Entry Created</p>
                  <p className="text-xs font-medium text-slate-400">{entry.date}</p>
                </div>
                <p className="text-lg font-black text-indigo-600">Rs. {entry.totalAmount.toLocaleString()}</p>
                <p className="text-xs text-slate-500 mt-1">{entry.desc}</p>
              </div>
            </div>

            {entry.payments.length === 0 ? (
              <p className="text-center text-slate-400 italic text-sm py-8">No payments recorded yet.</p>
            ) : (
              entry.payments.map((p, idx) => (
                <div key={p.id} className="flex items-start gap-4 animate-in fade-in slide-in-from-left-4 duration-300" style={{ animationDelay: `${idx * 100}ms` }}>
                  <div className="mt-1 w-8 h-8 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center font-bold text-xs">{idx + 1}</div>
                  <div className="flex-1 border-b border-slate-100 pb-4">
                    <div className="flex justify-between items-start mb-1">
                      <p className="text-sm font-bold text-slate-800">Payment Received / Settled</p>
                      <p className="text-xs font-medium text-slate-400">{p.date}</p>
                    </div>
                    <p className="text-lg font-black text-emerald-600">Rs. {p.amount.toLocaleString()}</p>
                    <div className="flex gap-4 mt-2">
                      <div className="bg-slate-50 px-2 py-1 rounded text-[10px] font-bold text-slate-500 border border-slate-100">
                        CHQ: {p.chaqueNo}
                      </div>
                      <div className="bg-slate-50 px-2 py-1 rounded text-[10px] font-bold text-slate-500 border border-slate-100">
                        VOU: {p.voucherNo}
                      </div>
                    </div>
                  </div>
                </div>
              ))
            )}

            {entry.status === 'Confirmed' && (
              <div className="flex items-start gap-4">
                <div className="mt-1 w-8 h-8 rounded-full bg-purple-50 text-purple-600 flex items-center justify-center font-bold text-xs">✓</div>
                <div className="flex-1 border-b border-slate-100 pb-4">
                  <div className="flex justify-between items-start mb-1">
                    <p className="text-sm font-bold text-slate-800">Identity Confirmed</p>
                    <p className="text-xs font-medium text-slate-400">Processing Date</p>
                  </div>
                  <p className="text-xs text-slate-600 italic">Confirmed by: {entry.confirmedBy}</p>
                </div>
              </div>
            )}
          </div>
        </div>

        <div className="p-8 bg-slate-50 border-t border-slate-100">
          <div className="flex justify-between items-center">
            <p className="text-sm font-bold text-slate-500">Total Settled</p>
            <p className="text-xl font-black text-emerald-600">
              Rs. {entry.payments.reduce((s, p) => s + p.amount, 0).toLocaleString()}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HistoryModal;
