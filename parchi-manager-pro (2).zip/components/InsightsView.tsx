
import React, { useState, useEffect } from 'react';
import { Entry } from '../types';
import { getFinancialInsights } from '../services/geminiService';

interface InsightsViewProps {
  entries: Entry[];
}

const InsightsView: React.FC<InsightsViewProps> = ({ entries }) => {
  const [insights, setInsights] = useState<string>('');
  const [loading, setLoading] = useState(false);

  const fetchInsights = async () => {
    setLoading(true);
    const result = await getFinancialInsights(entries);
    setInsights(result);
    setLoading(false);
  };

  useEffect(() => {
    fetchInsights();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-in fade-in duration-700">
      <div className="bg-gradient-to-br from-indigo-600 to-purple-700 p-12 rounded-[2.5rem] text-white shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full -translate-y-1/2 translate-x-1/2 blur-3xl" />
        <div className="absolute bottom-0 left-0 w-32 h-32 bg-indigo-400/20 rounded-full translate-y-1/2 -translate-x-1/2 blur-2xl" />
        
        <div className="relative z-10">
          <div className="flex items-center gap-4 mb-6">
            <div className="w-12 h-12 bg-white/20 backdrop-blur-md rounded-2xl flex items-center justify-center text-2xl">
              ✨
            </div>
            <div>
              <h2 className="text-3xl font-black">AI Smart Insights</h2>
              <p className="text-indigo-100 font-medium">Your personalized financial advisor</p>
            </div>
          </div>

          <div className="bg-white/10 backdrop-blur-lg border border-white/20 rounded-3xl p-8 min-h-[300px] flex flex-col">
            {loading ? (
              <div className="flex-1 flex flex-col items-center justify-center gap-4">
                <div className="w-12 h-12 border-4 border-white/30 border-t-white rounded-full animate-spin" />
                <p className="text-sm font-bold tracking-widest uppercase animate-pulse">Analyzing Financial Records...</p>
              </div>
            ) : (
              <div className="prose prose-invert max-w-none whitespace-pre-wrap text-lg leading-relaxed font-medium">
                {insights}
              </div>
            )}
            
            {!loading && (
              <button 
                onClick={fetchInsights}
                className="mt-8 self-start px-6 py-2 bg-white text-indigo-600 rounded-full text-xs font-bold hover:bg-indigo-50 transition-colors"
              >
                Refresh Analysis
              </button>
            )}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white p-8 rounded-3xl border border-slate-100">
          <h3 className="text-slate-400 font-bold text-[10px] uppercase tracking-widest mb-4">Cash Flow Health</h3>
          <p className="text-slate-600 text-sm leading-relaxed">
            Based on your entries, the AI examines your balance between payables and receivables to determine the stability of your liquidity over the next 30 days.
          </p>
        </div>
        <div className="bg-white p-8 rounded-3xl border border-slate-100">
          <h3 className="text-slate-400 font-bold text-[10px] uppercase tracking-widest mb-4">Risk Management</h3>
          <p className="text-slate-600 text-sm leading-relaxed">
            Automatically flags unconfirmed online transactions and overdue cheques that pose a risk to your daily operational cash requirements.
          </p>
        </div>
      </div>
    </div>
  );
};

export default InsightsView;
