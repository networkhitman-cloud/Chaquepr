
import React, { useMemo } from 'react';
// Fix: STATUS_COLORS is defined in constants.ts, not types.ts
import { Entry, Category } from '../types';
import { BANK_LIST, STATUS_COLORS } from '../constants';

interface TableViewProps {
  entries: Entry[];
  activeView: Category;
  statFilter: 'all' | 'paid' | 'pending' | 'overdue';
  onStatFilterChange: (filter: 'all' | 'paid' | 'pending' | 'overdue') => void;
  onEdit: (entry: Entry) => void;
  onDelete: (id: string) => void;
  onPay: (entry: Entry) => void;
  onConfirm: (entry: Entry) => void;
  onHistory: (entry: Entry) => void;
}

const TableView: React.FC<TableViewProps> = ({
  entries,
  activeView,
  statFilter,
  onStatFilterChange,
  onEdit,
  onDelete,
  onPay,
  onConfirm,
  onHistory
}) => {
  const stats = useMemo(() => {
    let total = 0, paid = 0, pending = 0, overdue = 0;
    entries.forEach(e => {
      const bal = e.totalAmount - e.payments.reduce((s, p) => s + p.amount, 0);
      total += e.totalAmount;
      paid += (e.totalAmount - bal);
      pending += bal;
      if (bal > 0 && (e.status === 'Overdue' || e.status === 'Active')) {
        overdue += bal;
      }
    });
    return { total, paid, pending, overdue };
  }, [entries]);

  const bankSummary = useMemo(() => {
    if (activeView !== Category.UNKNOWN_ONLINE) return null;
    const summary: Record<string, { count: number; total: number }> = {};
    entries.forEach(e => {
      if (e.status !== 'Confirmed' && e.bankName) {
        if (!summary[e.bankName]) summary[e.bankName] = { count: 0, total: 0 };
        summary[e.bankName].count++;
        summary[e.bankName].total += e.totalAmount;
      }
    });
    return summary;
  }, [entries, activeView]);

  const sortedEntries = [...entries].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      {/* Stat Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: 'Total Volume', value: stats.total, filter: 'all', color: 'slate' },
          { label: 'Settled/Paid', value: stats.paid, filter: 'paid', color: 'emerald' },
          { label: 'Pending Balance', value: stats.pending, filter: 'pending', color: 'amber' },
          { label: 'Overdue/Active', value: stats.overdue, filter: 'overdue', color: 'rose' },
        ].map(card => (
          <button
            key={card.filter}
            onClick={() => onStatFilterChange(card.filter as any)}
            className={`p-6 rounded-2xl border transition-all text-left ${
              statFilter === card.filter 
              ? `bg-${card.color}-600 border-${card.color}-600 text-white shadow-lg shadow-${card.color}-500/20` 
              : `bg-white border-slate-100 text-slate-800 hover:border-slate-300`
            }`}
          >
            <p className={`text-[10px] font-bold uppercase tracking-widest mb-1 ${statFilter === card.filter ? 'text-white/80' : 'text-slate-400'}`}>
              {card.label}
            </p>
            <div className="text-xl font-black">
              Rs. {card.value.toLocaleString()}
            </div>
          </button>
        ))}
      </div>

      {/* Bank Summary for Unknown Online */}
      {activeView === Category.UNKNOWN_ONLINE && bankSummary && Object.keys(bankSummary).length > 0 && (
        <div className="bg-amber-50 border border-amber-100 rounded-3xl p-8">
          <h3 className="text-amber-800 font-bold text-sm mb-4 uppercase tracking-wider">Unconfirmed Transactions by Bank</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {Object.entries(bankSummary).map(([bank, data]) => {
              // Fix: Destructure from typed object to resolve unknown property access
              const { count, total } = data as { count: number; total: number };
              return (
                <div key={bank} className="bg-white/50 p-4 rounded-xl border border-amber-200/50">
                  <p className="text-[10px] font-bold text-amber-700 mb-1">{bank}</p>
                  <p className="text-xs font-medium text-amber-600">{count} items</p>
                  <p className="text-sm font-bold text-slate-800 mt-1">Rs. {total.toLocaleString()}</p>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Main Table */}
      <div className="bg-white rounded-3xl shadow-sm border border-slate-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50/50">
                <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest">Date</th>
                <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest">Party Name</th>
                <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest">Reference</th>
                <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest">Bank Details</th>
                <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest">Amount</th>
                <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest">Paid</th>
                <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest">Balance</th>
                <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest">Status</th>
                <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {sortedEntries.length === 0 ? (
                <tr>
                  <td colSpan={9} className="px-6 py-12 text-center text-slate-400 italic">
                    No records found in this view.
                  </td>
                </tr>
              ) : (
                sortedEntries.map(entry => {
                  const paid = entry.payments.reduce((s, p) => s + p.amount, 0);
                  const balance = entry.totalAmount - paid;
                  const status = entry.status;

                  return (
                    <tr key={entry.id} className="hover:bg-slate-50 transition-colors group">
                      <td className="px-6 py-4 text-xs font-medium text-slate-500 whitespace-nowrap">
                        {entry.category === Category.UNKNOWN_ONLINE ? entry.transactionDate : entry.date}
                      </td>
                      <td className="px-6 py-4">
                        <p className="text-sm font-bold text-slate-800">{entry.partyName}</p>
                        {entry.desc && <p className="text-[10px] text-slate-400">{entry.desc}</p>}
                      </td>
                      <td className="px-6 py-4 text-xs text-slate-500">{entry.refNo || '-'}</td>
                      <td className="px-6 py-4">
                        <p className="text-xs font-semibold text-slate-700">{entry.bankName || '-'}</p>
                        <p className="text-[10px] text-slate-400 font-mono">{entry.bankAccountNum || '-'}</p>
                      </td>
                      <td className="px-6 py-4 text-sm font-bold text-slate-800">
                        {entry.totalAmount.toLocaleString()}
                      </td>
                      <td className="px-6 py-4 text-sm font-bold text-emerald-600">
                        {paid.toLocaleString()}
                      </td>
                      <td className="px-6 py-4 text-sm font-bold text-rose-600">
                        {balance.toLocaleString()}
                      </td>
                      <td className="px-6 py-4">
                        <span className={`px-2 py-1 rounded-full text-[10px] font-bold border ${(STATUS_COLORS as any)[status] || ''}`}>
                          {status}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-right">
                        <div className="flex items-center justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                          {activeView === Category.UNKNOWN_ONLINE ? (
                            status !== 'Confirmed' && (
                              <button onClick={() => onConfirm(entry)} title="Confirm Identity" className="p-2 hover:bg-purple-100 text-purple-600 rounded-lg transition-colors text-xs">✅</button>
                            )
                          ) : (
                            balance > 0 && (
                              <button onClick={() => onPay(entry)} title="Record Payment" className="p-2 hover:bg-emerald-100 text-emerald-600 rounded-lg transition-colors text-xs">💸</button>
                            )
                          )}
                          <button onClick={() => onHistory(entry)} title="History" className="p-2 hover:bg-blue-100 text-blue-600 rounded-lg transition-colors text-xs">📜</button>
                          <button onClick={() => onEdit(entry)} title="Edit" className="p-2 hover:bg-indigo-100 text-indigo-600 rounded-lg transition-colors text-xs">✏️</button>
                          <button onClick={() => onDelete(entry.id)} title="Delete" className="p-2 hover:bg-rose-100 text-rose-600 rounded-lg transition-colors text-xs">🗑️</button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default TableView;
