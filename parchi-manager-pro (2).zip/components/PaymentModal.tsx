
import React, { useState } from 'react';
import { Entry, Payment } from '../types';

interface PaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  entry: Entry;
  onSave: (payment: Payment) => void;
}

const PaymentModal: React.FC<PaymentModalProps> = ({ isOpen, onClose, entry, onSave }) => {
  const [formData, setFormData] = useState<Partial<Payment>>({
    date: new Date().toISOString().split('T')[0],
    amount: 0,
    chaqueNo: '',
    voucherNo: '',
  });

  const balance = entry.totalAmount - entry.payments.reduce((s, p) => s + p.amount, 0);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.amount! > balance) {
      alert("Payment cannot exceed remaining balance!");
      return;
    }
    onSave({
      id: Date.now().toString(),
      ...formData
    } as Payment);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
      <div className="bg-white rounded-3xl shadow-2xl w-full max-w-md overflow-hidden animate-in zoom-in-95 duration-300">
        <div className="px-8 py-6 border-b border-slate-100 flex items-center justify-between">
          <h2 className="text-xl font-bold text-slate-800">Record Payment</h2>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600 transition-colors">✕</button>
        </div>

        <form onSubmit={handleSubmit} className="p-8 space-y-6">
          <div className="p-4 bg-rose-50 border border-rose-100 rounded-2xl">
            <p className="text-[10px] font-bold text-rose-400 uppercase tracking-widest mb-1">Current Balance Due</p>
            <p className="text-2xl font-black text-rose-600">Rs. {balance.toLocaleString()}</p>
          </div>

          <div className="space-y-4">
            <div className="space-y-1">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Payment Date</label>
              <input 
                type="date"
                required
                className="w-full bg-slate-50 border-slate-200 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
                value={formData.date}
                onChange={(e) => setFormData({ ...formData, date: e.target.value })}
              />
            </div>

            <div className="space-y-1">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Amount to Pay</label>
              <input 
                type="number"
                required
                max={balance}
                className="w-full bg-slate-50 border-slate-200 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
                value={formData.amount}
                onChange={(e) => setFormData({ ...formData, amount: parseFloat(e.target.value) })}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Cheque #</label>
                <input 
                  type="text"
                  required
                  className="w-full bg-slate-50 border-slate-200 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
                  value={formData.chaqueNo}
                  onChange={(e) => setFormData({ ...formData, chaqueNo: e.target.value })}
                />
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Voucher #</label>
                <input 
                  type="text"
                  required
                  className="w-full bg-slate-50 border-slate-200 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
                  value={formData.voucherNo}
                  onChange={(e) => setFormData({ ...formData, voucherNo: e.target.value })}
                />
              </div>
            </div>
          </div>

          <button 
            type="submit"
            className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-4 rounded-xl transition-all shadow-lg shadow-emerald-500/20 active:scale-95"
          >
            Confirm Settlement
          </button>
        </form>
      </div>
    </div>
  );
};

export default PaymentModal;
