
import React from 'react';
import { Entry, Category, ViewType } from '../types';

interface DashboardProps {
  entries: Entry[];
  onViewChange: (view: ViewType) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ entries, onViewChange }) => {
  const getSummary = (category: Category) => {
    return entries
      .filter(e => e.category === category)
      .reduce((sum, e) => {
        const bal = e.totalAmount - e.payments.reduce((s, p) => s + p.amount, 0);
        return sum + bal;
      }, 0);
  };

  const cards = [
    { title: 'Chaque Receivables', amount: getSummary(Category.CHAQUE_RECEIVABLES), color: 'emerald', value: Category.CHAQUE_RECEIVABLES },
    { title: 'Chaque Payables', amount: getSummary(Category.CHAQUE_PAYABLES), color: 'rose', value: Category.CHAQUE_PAYABLES },
    { title: 'Long Term Receivables', amount: getSummary(Category.LONG_TERM_RECEIVABLES), color: 'indigo', value: Category.LONG_TERM_RECEIVABLES },
    { title: 'Long Term Payables', amount: getSummary(Category.LONG_TERM_PAYABLES), color: 'amber', value: Category.LONG_TERM_PAYABLES },
    { title: 'Unknown Online', amount: getSummary(Category.UNKNOWN_ONLINE), color: 'purple', value: Category.UNKNOWN_ONLINE },
  ];

  const totalBalance = entries.reduce((sum, e) => {
    const bal = e.totalAmount - e.payments.reduce((s, p) => s + p.amount, 0);
    return sum + (e.category.includes('Receivables') ? bal : -bal);
  }, 0);

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <div className="col-span-full bg-white p-8 rounded-3xl shadow-sm border border-slate-100 flex items-center justify-between">
          <div>
            <h2 className="text-slate-500 font-medium uppercase tracking-widest text-xs mb-2">Net Financial Standing</h2>
            <div className={`text-5xl font-extrabold tracking-tight ${totalBalance >= 0 ? 'text-emerald-600' : 'text-rose-600'}`}>
              Rs. {totalBalance.toLocaleString()}
            </div>
          </div>
          <div className="hidden md:block">
            <div className="w-16 h-16 rounded-full bg-slate-50 flex items-center justify-center text-3xl">💰</div>
          </div>
        </div>

        {cards.map(card => (
          <button
            key={card.title}
            onClick={() => onViewChange(card.value)}
            className="group bg-white p-8 rounded-3xl shadow-sm border border-slate-100 text-left transition-all hover:shadow-xl hover:-translate-y-1"
          >
            <div className={`w-12 h-12 rounded-2xl bg-${card.color}-50 text-${card.color}-600 flex items-center justify-center text-xl mb-6 group-hover:scale-110 transition-transform`}>
              {card.title.includes('Receivable') ? '⬇️' : '⬆️'}
            </div>
            <h3 className="text-slate-500 text-sm font-semibold mb-1">{card.title}</h3>
            <div className={`text-2xl font-bold text-slate-800`}>
              Rs. {card.amount.toLocaleString()}
            </div>
            <p className="mt-4 text-xs text-slate-400 font-medium flex items-center gap-1 group-hover:text-indigo-500 transition-colors">
              Click to view detailed ledger <span>→</span>
            </p>
          </button>
        ))}
      </div>
    </div>
  );
};

export default Dashboard;
