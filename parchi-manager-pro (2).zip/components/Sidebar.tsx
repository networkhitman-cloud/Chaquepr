
import React from 'react';
import { Category, ViewType } from '../types';

interface SidebarProps {
  activeView: ViewType;
  onViewChange: (view: ViewType) => void;
  onAddEntry: () => void;
  searchType: 'party' | 'date' | 'bank';
  setSearchType: (type: 'party' | 'date' | 'bank') => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ 
  activeView, 
  onViewChange, 
  onAddEntry,
  searchType,
  setSearchType,
  searchQuery,
  setSearchQuery
}) => {
  const navItems = [
    { label: 'Chaque Receivables', icon: '💰', value: Category.CHAQUE_RECEIVABLES },
    { label: 'Chaque Payables', icon: '🏦', value: Category.CHAQUE_PAYABLES },
    { label: 'Long Term Payables', icon: '⏳', value: Category.LONG_TERM_PAYABLES },
    { label: 'Long Term Receivables', icon: '📅', value: Category.LONG_TERM_RECEIVABLES },
    { label: 'Unknown Online', icon: '🌐', value: Category.UNKNOWN_ONLINE },
  ];

  return (
    <aside className="w-72 bg-slate-900 text-slate-300 flex flex-col h-full shadow-2xl z-30">
      <div className="p-6">
        <div className="flex items-center gap-3 mb-8">
          <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center text-white text-xl shadow-lg shadow-indigo-500/20">
            📘
          </div>
          <div>
            <h1 className="text-white font-bold leading-none">PARCHI</h1>
            <p className="text-[10px] text-slate-500 font-bold tracking-widest mt-1">MANAGER PRO</p>
          </div>
        </div>

        <div className="bg-slate-800/50 rounded-xl p-4 mb-6 border border-slate-700/50">
          <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-3 flex items-center gap-2">
            <span>🔍</span> Smart Search
          </p>
          <select 
            className="w-full bg-slate-900 border-slate-700 text-xs rounded-lg p-2 mb-2 focus:ring-1 focus:ring-indigo-500 outline-none"
            value={searchType}
            onChange={(e) => setSearchType(e.target.value as any)}
          >
            <option value="party">Party Name</option>
            <option value="date">Date</option>
            <option value="bank">Bank Name</option>
          </select>
          <input 
            type={searchType === 'date' ? 'date' : 'text'}
            placeholder={`Search ${searchType}...`}
            className="w-full bg-slate-900 border-slate-700 text-xs rounded-lg p-2 focus:ring-1 focus:ring-indigo-500 outline-none"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>

        <button 
          onClick={onAddEntry}
          className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-bold py-3 rounded-xl transition-all shadow-lg shadow-indigo-500/20 active:scale-[0.98] mb-8"
        >
          + Add New Entry
        </button>

        <nav className="space-y-1">
          {navItems.map((item) => (
            <button
              key={item.value}
              onClick={() => onViewChange(item.value)}
              className={`w-full text-left px-4 py-3 rounded-xl flex items-center gap-3 transition-colors ${
                activeView === item.value 
                ? 'bg-indigo-600/10 text-indigo-400 font-semibold' 
                : 'hover:bg-slate-800 hover:text-white'
              }`}
            >
              <span className="text-lg">{item.icon}</span>
              <span className="text-sm">{item.label}</span>
            </button>
          ))}
        </nav>
      </div>

      <div className="mt-auto p-6 space-y-2">
        <button
          onClick={() => onViewChange('dashboard')}
          className={`w-full text-left px-4 py-3 rounded-xl flex items-center gap-3 transition-colors ${
            activeView === 'dashboard' 
            ? 'bg-indigo-600 text-white font-semibold' 
            : 'bg-slate-800/50 hover:bg-slate-800 hover:text-white'
          }`}
        >
          <span className="text-lg">📊</span>
          <span className="text-sm">Dashboard</span>
        </button>

        <button
          onClick={() => onViewChange('insights')}
          className={`w-full text-left px-4 py-3 rounded-xl flex items-center gap-3 transition-colors ${
            activeView === 'insights' 
            ? 'bg-purple-600 text-white font-semibold' 
            : 'bg-slate-800/50 hover:bg-slate-800 hover:text-white'
          }`}
        >
          <span className="text-lg">✨</span>
          <span className="text-sm font-semibold text-purple-400">AI Insights</span>
        </button>
      </div>
    </aside>
  );
};

export default Sidebar;
