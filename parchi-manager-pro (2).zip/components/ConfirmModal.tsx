
import React, { useState } from 'react';
import { Entry } from '../types';

interface ConfirmModalProps {
  isOpen: boolean;
  onClose: () => void;
  entry: Entry;
  onSave: (id: string, customerName: string, confirmedBy: string) => void;
}

const ConfirmModal: React.FC<ConfirmModalProps> = ({ isOpen, onClose, entry, onSave }) => {
  const [customerName, setCustomerName] = useState('');
  const [confirmedBy, setConfirmedBy] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(entry.id, customerName, confirmedBy);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
      <div className="bg-white rounded-3xl shadow-2xl w-full max-w-md overflow-hidden animate-in zoom-in-95 duration-300">
        <div className="px-8 py-6 border-b border-slate-100 flex items-center justify-between">
          <h2 className="text-xl font-bold text-slate-800">Confirm Online Identity</h2>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600 transition-colors">✕</button>
        </div>

        <form onSubmit={handleSubmit} className="p-8 space-y-6">
          <div className="p-4 bg-purple-50 border border-purple-100 rounded-2xl">
            <p className="text-[10px] font-bold text-purple-400 uppercase tracking-widest mb-1">Transaction Source</p>
            <p className="text-sm font-bold text-slate-800">{entry.bankName} - {entry.partyName}</p>
            <p className="text-lg font-black text-purple-600 mt-1">Rs. {entry.totalAmount.toLocaleString()}</p>
          </div>

          <div className="space-y-4">
            <div className="space-y-1">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Actual Customer Name</label>
              <input 
                type="text"
                required
                placeholder="Who sent this payment?"
                className="w-full bg-slate-50 border-slate-200 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
                value={customerName}
                onChange={(e) => setCustomerName(e.target.value)}
              />
            </div>

            <div className="space-y-1">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Confirmed By (Officer)</label>
              <input 
                type="text"
                required
                placeholder="Your name"
                className="w-full bg-slate-50 border-slate-200 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
                value={confirmedBy}
                onChange={(e) => setConfirmedBy(e.target.value)}
              />
            </div>
          </div>

          <button 
            type="submit"
            className="w-full bg-purple-600 hover:bg-purple-500 text-white font-bold py-4 rounded-xl transition-all shadow-lg shadow-purple-500/20 active:scale-95"
          >
            Mark as Confirmed
          </button>
        </form>
      </div>
    </div>
  );
};

export default ConfirmModal;
